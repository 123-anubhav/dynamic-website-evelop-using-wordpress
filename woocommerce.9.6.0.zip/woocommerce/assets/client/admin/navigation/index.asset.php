<?php return array('dependencies' => array('lodash', 'wc-settings', 'wp-element', 'wp-hooks', 'wp-i18n', 'wp-url'), 'version' => '40e741899f51a9766e55');
